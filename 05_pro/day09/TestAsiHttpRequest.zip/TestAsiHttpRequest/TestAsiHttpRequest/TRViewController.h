//
//  TRViewController.h
//  TestAsiHttpRequest
//
//  Created by tarena on 14-5-28.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
@interface TRViewController : UIViewController<ASIHTTPRequestDelegate>

@end
