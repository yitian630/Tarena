//
//  TRViewController.m
//  TestAsiHttpRequest
//
//  Created by tarena on 14-5-28.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRViewController.h"
#import "ASIHTTPRequest.h"
@interface TRViewController ()
@property (nonatomic, strong)ASIHTTPRequest *request;
@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	
}
- (IBAction)syncAction:(id)sender {
    
    NSString *path = @"http://www.baidu.com";
    
    NSURL *url = [NSURL URLWithString:path];
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    
    //开始同步请求
    [request startSynchronous];
//    如果返回值是文本的话
    NSString *htmlString = [request responseString];
//    如果返回文件的话 就用
//    NSData *data = [request responseData];
    NSLog(@"%@",htmlString);
    
    
}
- (IBAction)AsynchronousAction:(id)sender {
    
    NSString *path = @"http://d.hiphotos.baidu.com/news/pic/item/8435e5dde71190ef58edfd25cc1b9d16fdfa6031.jpg";
    
    NSURL *url = [NSURL URLWithString:path];
    
    self.request = [ASIHTTPRequest requestWithURL:url];
    
    self.request.downloadProgressDelegate = self;
//    设置下载文件的临时路径
     [self.request setTemporaryFileDownloadPath:@"/Users/tarena/Music/temp.jpg"];

//    设置下载文件的路径
    [self.request setDownloadDestinationPath:@"/Users/tarena/Music/bbbbb.jpg"];
    
    [self.request startAsynchronous];
}

- (void)setProgress:(float)newProgress{
    NSLog(@"%f",newProgress);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
