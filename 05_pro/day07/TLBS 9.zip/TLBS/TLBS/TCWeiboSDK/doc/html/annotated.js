var annotated =
[
    [ "WeiboApi", "interface_weibo_api.html", "interface_weibo_api" ],
    [ "WeiboApiObject", "interface_weibo_api_object.html", "interface_weibo_api_object" ],
    [ "<WeiboAuthDelegate>", "protocol_weibo_auth_delegate-p.html", "protocol_weibo_auth_delegate-p" ],
    [ "<WeiboRequestDelegate>", "protocol_weibo_request_delegate-p.html", "protocol_weibo_request_delegate-p" ]
];