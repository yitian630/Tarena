var interface_weibo_api =
[
    [ "cancelAuth", "interface_weibo_api.html#a990a14ba53bb85109f04a36daa723f2c", null ],
    [ "checkAuthValid:andDelegete:", "interface_weibo_api.html#a30acc2a73ac30c0acfc55d0e8e02bc1b", null ],
    [ "getToken", "interface_weibo_api.html#acff1e529673fe7da19e7bec11c5a94ac", null ],
    [ "handleOpenURL:", "interface_weibo_api.html#a77a481235be295ee6230f1821731c4aa", null ],
    [ "initWithAppKey:andSecret:andRedirectUri:andAuthModeFlag:andCachePolicy:", "interface_weibo_api.html#a8f1e910a9d7a1f6835a849eabeaa08bc", null ],
    [ "loginWithDelegate:andRootController:", "interface_weibo_api.html#a7c472ac2761e4c73817320ba9b549100", null ],
    [ "requestWithParams:apiName:httpMethod:delegate:", "interface_weibo_api.html#a5ab74c7c65125cf314263e7a7ef4a9c2", null ],
    [ "SetToken:", "interface_weibo_api.html#aec8b529e7b2e33b7cced2077195b9dd6", null ],
    [ "reqDic", "interface_weibo_api.html#a5b655ab748c7ce0d9098a12e9c54b922", null ],
    [ "weiboObj", "interface_weibo_api.html#a4f78f9fd1fbb0ba5dd15bf2e1f70ab7a", null ]
];