var protocol_weibo_request_delegate_p =
[
    [ "didFailWithError:reqNo:", "protocol_weibo_request_delegate-p.html#abbdc68e1688984fe656cf4b0acff4cd4", null ],
    [ "didNeedRelogin:reqNo:", "protocol_weibo_request_delegate-p.html#ad53a8c6cbb2397358c27f3938aaa8006", null ],
    [ "didReceiveRawData:reqNo:", "protocol_weibo_request_delegate-p.html#a86fdb9dcab62cc6391150ab6c3cd5b7c", null ]
];