//
//  constant.h
//  TCWeiboSDK-LightVersion
//
//  Created by heloyue on 13-5-8.
//  Copyright (c) 2013年 heloyue. All rights reserved.
//

#ifndef TCWeiboSDK_LightVersion_constant_h
#define TCWeiboSDK_LightVersion_constant_h



#define WiressSDKDemoAppKey     @"801459107"
#define WiressSDKDemoAppSecret  @"45e8fda363de618b07aeebf6b9919174"
#define REDIRECTURI             @"http://auth.tarena.com"


#endif
