//
//  TRMyWeiboApi.h
//  TLBS
//
//  Created by tarena on 14-5-20.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "WeiboApi.h"

@interface TRMyWeiboApi : NSObject
+(WeiboApi *)shareWeiboApi;


@end
