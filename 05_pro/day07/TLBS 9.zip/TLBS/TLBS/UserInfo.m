//
//  UserInfo.m
//  Day10WeiboDemo
//
//  Created by apple on 13-11-25.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo
@end
