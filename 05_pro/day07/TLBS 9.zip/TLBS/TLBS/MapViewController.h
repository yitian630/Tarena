//
//  MapViewController.h
//  Day10WeiboDemo
//
//  Created by apple on 13-11-29.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapViewController : UIViewController
@property (nonatomic, strong)NSMutableArray *weibos;
@end
